title: 世上最简单的Docker安装+使用
date: '2019-09-03 14:29:12'
updated: '2019-09-03 14:33:34'
tags: [Docker]
permalink: /docker
---
![](https://img.hacpai.com/bing/20190522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言

> 后续文章所用到的所有应用都基于Docker安装，所以有必要先了解一下关于Docker的一些基础知识，经过小编一段时间的使用后，真的感觉是一直用一直爽。

## 什么是Docker？

Docker 是一个开源的应用容器引擎，基于 Go 语言 并遵从Apache2.0协议开源。
Docker 可以让开发者打包他们的应用以及依赖包到一个轻量级、可移植的容器中，然后发布到任何流行的 Linux 机器上，也可以实现虚拟化。
容器是完全使用沙箱机制，相互之间不会有任何接口（类似 iPhone 的 app）,更重要的是容器性能开销极低。
Docker 从 17.03 版本之后分为CE（Community Edition: 社区版） 和 EE（Enterprise Edition: 企业版），我们用社区版就可以了。

## 为什么使用Docker？

Docker的好处有很多，学习和使用的理由也很多，例如：
* 无论是部署应用、安装应用或者是搭建环境都十分的方便，真正体现了一处安装到处使用，灵活迁移开发的应用程序。
* 大大节省资源开销，Docker 与云的结合，让云空间得到更充分的利用。不仅解决了硬件管理的问题，也改变了虚拟化的方式。
* 启动速度快，毫秒级速度。
* 沙箱隔离机制，保证服务高可用。

## Docker的安装与部署
### 环境准备
1. 内核：linux。
2. 操作系统：Ubuntu 16.04 LTS 。
3. 镜像加速器：阿里云镜像。

#### 卸载旧版本Docker 如果未安装请忽略
```sh
$ apt-get remove docker docker-engine docker.io
```

```sh
Reading package lists... Done
Building dependency tree       
Reading state information... Done
Package 'docker-engine' is not installed, so not removed
Package 'docker' is not installed, so not removed
Package 'docker.io' is not installed, so not removed
0 upgraded, 0 newly installed, 0 to remove and 122 not upgraded.
```
#### 使用脚本安装
```sh
$ curl -fsSL get.docker.com -o get-docker.sh
$ sudo sh get-docker.sh --mirror Aliyun
```
```sh
# Executing docker install script, commit: 6bf300318ebaab958c4adc341a8c7bb9f3a54a1a
+ sh -c apt-get update -qq >/dev/null
+ sh -c apt-get install -y -qq apt-transport-https ca-certificates curl >/dev/null
+ sh -c curl -fsSL "https://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg" | apt-key add -qq - >/dev/null
+ sh -c echo "deb [arch=amd64] https://mirrors.aliyun.com/docker-ce/linux/ubuntu xenial stable" > /etc/apt/sources.list.d/docker.list
+ sh -c apt-get update -qq >/dev/null
+ [ -n  ]
+ sh -c apt-get install -y -qq --no-install-recommends docker-ce >/dev/null
+ sh -c docker version
Client: Docker Engine - Community
 Version:           19.03.1
 API version:       1.40
 Go version:        go1.12.5
 Git commit:        74b1e89e8a
 Built:             Thu Jul 25 21:21:35 2019
 OS/Arch:           linux/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.1
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.5
  Git commit:       74b1e89e8a
  Built:            Thu Jul 25 21:20:09 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.2.6
  GitCommit:        894b81a4b802e4eb2a91d1ce216b8817763c29fb
 runc:
  Version:          1.0.0-rc8
  GitCommit:        425e105d5a03fabd737a126ad93d62a9eeede87f
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683
If you would like to use Docker as a non-root user, you should now consider
adding your user to the "docker" group with something like:

  sudo usermod -aG docker your-user

Remember that you will have to log out and back in for this to take effect!

WARNING: Adding a user to the "docker" group will grant the ability to run
         containers which can be used to obtain root privileges on the
         docker host.
         Refer to https://docs.docker.com/engine/security/security/#docker-daemon-attack-surface
         for more information.
```
#### 启动Docker CE
```sh
$ sudo systemctl enable docker
$ sudo systemctl start docker
```
#### 新建Docker用户组
```sh
$ sudo groupadd docker
$ sudo usermod -aG docker $USER
```
#### 配置镜像加速器
* 以Ubuntu 16.04为例 各操作系统有所差异。
* 在/etc/docker/daemon.json文件中加入以下代码(如果文件不存在，自己创建)。
```json
{
       "registry-mirrors": [
          "https://culfukli.mirror.aliyuncs.com"
       ]
}
```
> 注意，一定要保证该文件符合 json 规范，否则 Docker 将不能启动。

* 重启Docker
```sh
$ sudo systemctl daemon-reload
$ sudo systemctl restart docker
```
* 使用docker info命令查看配置信息，看到以下信息说明配置成功。
```sh
 Registry Mirrors:
  https://culfukli.mirror.aliyuncs.com/
```
#### 测试Docker
##### 查看Docker版本
```sh
$ docker -v
```
```sh
> Docker version 19.03.1, build 74b1e89e8a
```
##### 测试安装tomcat
###### 拉取官方tomcat
``` sh
$ docker pull tomcat
```
###### 查看已安装的镜像
```sh
$ docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
tomcat              latest              96c4e536d0eb        12 days ago         506MB
```
###### 启动tomcat
```sh
$ docker run --name tomcat -p 8080:8080 -v $PWD/webapps:/usr/local/tomcat/webapps -d tomcat
```
* -p 8080:8080 表时宿主机的8080端口映射到容器的8080端口。
* -v $PWD/webapps:/usr/local/tomcat/webapps表时宿主机的webapps目录挂载到容器的webapps目录。
* -d 表示后台启动。
* 8080:8080 （这种写法左边是宿主机，右边是容器）。
###### 查看正在运行的镜像
```sh
$ docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS                    NAMES
547f001f782d        tomcat              "catalina.sh run"   About an hour ago   Up About an hour    0.0.0.0:8080->8080/tcp   tomcat
```
此时去浏览器访问ip:8080可以看到我们熟悉的页面。
![WX201909031426152x.png](https://img.hacpai.com/file/2019/09/WX201909031426152x-7a36fc7f.png)

###### 停止正在运行的镜像
```sh
$ docker stop 547f001f782d
$ docker ps -a
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS                            PORTS               NAMES
547f001f782d        tomcat              "catalina.sh run"   2 hours ago         Exited (143) About a minute ago                       tomcat
$ docker rm  547f001f782d
```
## 常用命令
运行Docker镜像
```sh
docker run -d image-name
```
查看可用的镜像
```sh
docker images
```
查看所有运行的镜像
```sh
docker ps -a
```
查看最近运行的镜像
```sh
docker ps -l
```
停止运行Docker镜像
```sh
docker stop container_id
```
删除后台运行Docker镜像
```sh
docker rm container_id
```
删除镜像
```sh
docker rmi image-name
```
以交互方式进入容器
```sh
docker exec -it container_id sh
```

## 总结
* 简化配置，构建一次后打包后就可以用作测试环境，也可以用作生产环境或与预生产环境，可以省去很多测试环节。比如一台服务器可以进行测试多个版本的测试，不用等待。
* 可以解决开发人员部署环境的困难，好比如一个刚来的新同事安装环境可能需要半天时间，但要是直接运行一个已经配好的容器的话就方便多了。
* 应用隔离，服务器整合，一个服务器可以用docker部署多套业务，并且隔离性很高（除了虚拟机）。
* 对与运维来说，可以快速的进行扩容，减少原利用率
* 每个小的服务都可以进行集群，docker对资源的利用比较小，可以在一台服务器启动多台，相比其他产品对服务器的I/O使用上要多例如(启动storm)。
* 可以多平台部署。

## 参考文档
[李卫民blog](https://funtl.com/zh/docker)
[Docker教程](https://www.runoob.com/docker/docker-tutorial.html)
